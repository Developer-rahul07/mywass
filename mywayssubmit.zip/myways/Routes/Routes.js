const express = require('express');
const router = express.Router();
const booksController = require('../Controllers/Food-Controller');
const bodyParser = require('body-parser');
router.use(bodyParser.urlencoded({ extended: false }));

router.get('/food',booksController.getAllfoods);
router.post('/food',booksController.getAddfoods);
router.get('/food/:id',booksController.getByFoodId);
router.put('/food/:id',booksController.getUpdateFood);
router.delete('/food/:id',booksController.getDeleteFood);

module.exports = router;