const express = require('express');
const Food = require('../Model/Food');

const getAllfoods = async (req, res) => {

    try {
        let values = await Food.find();
        return res.status(200).json({ values });
    } catch (err) {
        console.log(err);
        return res.status(400).json({ message: "No produuct Found" });
    }

}

const getAddfoods = async (req, res) => {

    const foodName = req.body.foodName;
    const foodType = req.body.foodType;
    const maxDeliveryTime = req.body.maxDeliveryTime;
    const price = req.body.price;

    try {
        let food = new Food({
            foodName, foodType, maxDeliveryTime, price
        });
        await food.save();
        return res.status(201).json({ food });
    }
    catch (err) {
        console.log(err);
        return res.status(500).json({ message: "Unable to Add food item" });
    }

}

const getByFoodId = async (req, res, next) => {

    const id = req.params.id;

    try {
        let food = await Food.findById(id);
        return res.status(200).json({ food });
    }
    catch (err) {
        console.log(err);
        return res.status(404).json({ message: "No Food Item Found" });
    }

}

const getUpdateFood = async (req, res) => {

    const id = req.params.id;
    const foodName = req.body.foodName;
    const foodType = req.body.foodType;
    const maxDeliveryTime = req.body.maxDeliveryTime;
    const price = req.body.price;


    try {
        let food = await Food.findByIdAndUpdate(id, {
            foodName, foodType, maxDeliveryTime, price
        }
        )
        food = await food.save()
        return res.status(200).json({ food });
    }
    catch (err) {
        console.log(err);
        return res.status(404).json({ message: "unable to update with this id" });
    }
}

const getDeleteFood = async (req, res, next) => {

    const id = req.params.id;

    try {
        let food = await Food.findByIdAndRemove(id)
        return res.status(200).json({ message: "Food Successfully deleted" });
    }
    catch (err) {
        console.log(err);
        return res.status(404).json({ message: "unable to delete with this id" });
    }


}

exports.getAllfoods = getAllfoods;
exports.getAddfoods = getAddfoods;
exports.getByFoodId = getByFoodId;
exports.getUpdateFood = getUpdateFood;
exports.getDeleteFood = getDeleteFood;